﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using WindowsFormsApp29.Class;

namespace WindowsFormsApp29
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {


        }



        private void Form1_Load(object sender, EventArgs e)
        {
            GetPlusDebt();

            DataTable datatable = DebtDal.GetCatagory();
            int number = 0;

            for (; ; )
            {


                try
                {
                    cbxCatagory.Items.Add(datatable.Rows[number][0]);
                    number++;
                }
                catch (Exception)
                {

                    break;
                }


            }




            dataGridView1.DataSource = DebtDal.DataGetAll();
            dataGridView1.Columns[0].Visible = false;

        }

        private void GetPlusDebt()
        {
            lblplusdebt.Text = DebtDal.GetSumAmount().ToString();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            try
            {
                dateTimePicker1.Format = DateTimePickerFormat.Custom;
                DebtDal.DataAdd(new Debt() { Amount = Convert.ToDecimal(txtAmount.Text), CatagoryId = cbxCatagory.SelectedIndex + 1, DateTimeEnd = dateTimePicker1.MinDate });
                dataGridView1.DataSource = DebtDal.DataGetAll();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);

            }
            GetPlusDebt();

        }

        

        
        

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {


            groupBox2.Enabled = true;
            textBox2.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
            textBox1.Text = dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();

            try
            {
                dateTimePicker2.Value = Convert.ToDateTime(dataGridView1.Rows[e.RowIndex].Cells[2].Value);
            }
            catch (Exception)
            {

               
            }
           

        }

        private void button2_Click(object sender, EventArgs e)
        {


            var result = MessageBox.Show("Silmek istediginiz borc silinecektir\nEmin misiniz?", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (result==DialogResult.Yes)
            {
                try
                {
                    DebtDal.DeleteDebt(Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value));
                    dataGridView1.DataSource = DebtDal.DataGetAll();
                }
                catch (Exception)
                {


                }
                GetPlusDebt();
            }

           
            

            // MessageBox.Show(dataGridView1.SelectedRows[0].Cells[0].Value.ToString());
        }


        

        

       

        
    }
}
