﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using WindowsFormsApp29;
using System.Data;

namespace WindowsFormsApp29.Class
{
    public class DebtDal
    {

        public static DataTable DataGetAll()
        {
            SqlConnection connection = new SqlConnection(@"server=(localdb)\MSSQLLocalDB;initial catalog=Debts; integrated Security=true");
            SqlDataAdapter dataadapter = new SqlDataAdapter(@"select Debt.Id, Debt.Amount as 'Tutar',Debt.DateTimeEnd as 'Son Odeme Tarihi',Catagory.Type as  'Kategori' from Debt inner join  Catagory on Debt.CatagoryId = Catagory.Id", connection);
            DataTable datatable = new DataTable();
            dataadapter.Fill(datatable);

            return datatable;

        }


        public static void DataAdd(Debt debt)
        {
            SqlConnection connection = new SqlConnection(@"server=(localdb)\MSSQLLocalDB;initial catalog=Debts;integrated security=true");
            SqlCommand command = new SqlCommand("insert into Debt(Amount,DateTimeEnd,CatagoryId) values (@amount,@datetimeend,@catagoryid)", connection);

            command.Parameters.AddWithValue("@amount", debt.Amount);
            command.Parameters.Add("@datetimeend", debt.DateTimeEnd);
            command.Parameters.Add("@catagoryid", debt.CatagoryId);

            connection.Open();
            command.ExecuteNonQuery();
            connection.Close();
            DataGetAll();
        }

        public static DataTable GetCatagory()
        {
            SqlConnection connection = new SqlConnection(@"server=(localdb)\MSSQLLocalDB;initial catalog=Debts;integrated security=true");
            SqlDataAdapter dataadapter = new SqlDataAdapter("select Type from Catagory order by Id asc", connection);
            DataTable datatable = new DataTable();

            dataadapter.Fill(datatable);

            return datatable;

        }

        public static void DeleteDebt(int id)
        {
            SqlConnection connection = new SqlConnection(@"server=(localdb)\MSSQLLocalDB;initial catalog=Debts;integrated security=true");
            SqlCommand command = new SqlCommand("delete  from Debt where Id=@id", connection);
            command.Parameters.AddWithValue("@id", id);
            connection.Open();
            command.ExecuteNonQuery();
            connection.Close();

        }

        public static int GetSumAmount()
        {
            SqlConnection connection = new SqlConnection(@"server=(localdb)\MSSQLLocalDB;initial catalog=Debts;integrated security=true");
            SqlCommand command = new SqlCommand("select sum( Amount) from Debt", connection);
            connection.Open();
            int number = 0;
            try
            {
                number = Convert.ToInt32(command.ExecuteScalar());
            }
            catch (Exception)
            {


            }


            return number;

        }
    }
}
