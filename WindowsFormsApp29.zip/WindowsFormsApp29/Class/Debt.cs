﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp29
{
    public class Debt
    {
        public int Id { get; set; }
        public DateTime DateTimeEnd { get; set; }

        public decimal Amount { get; set; }
        public int CatagoryId { get; set; }
    }
}
